﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    /// <summary>
    /// Sample plugin template for Create and Update operations in Dataverse (Dynamics 365).
    /// </summary>
    public class $safeitemname$ : IPlugin
    {
        /// <summary>
        /// Main entry point of the plugin execution.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // Get the context of the plugin execution.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Check if the plugin is triggered by a Create or Update operation on an entity.
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                // Get the target entity from the plugin context.
                Entity entity = (Entity)context.InputParameters["Target"];

                // Create a service factory to get the organization service.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    // TODO: Add your plugin logic here for the Create and Update operations.
                    // Example: Perform some calculations, validations, or updates to related records.

                    // For example:
                    // string name = entity.GetAttributeValue<string>("name");
                    // int age = entity.GetAttributeValue<int>("age");

                    // Perform your business logic based on the entity data.

                    // Finally, if needed, update the entity in Dataverse using the service.
                    // service.Update(entity);
                }
                catch (Exception ex)
                {
                    //throw new InvalidPluginExecutionException(ex.ToString());
                }
            }
        }
    }
}
