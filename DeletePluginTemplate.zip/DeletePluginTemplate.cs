﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace $rootnamespace$
{
    /// <summary>
    /// Sample plugin template for Delete operations in Dataverse (Dynamics 365).
    /// </summary>
    public class $safeitemname$ : IPlugin
    {
        /// <summary>
        /// Main entry point of the plugin execution.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // Get the context of the plugin execution.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Check if the plugin is triggered by a Delete operation on an entity.
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
            {
                // Get the target entity from the plugin context.
                EntityReference entityReference = (EntityReference)context.InputParameters["Target"];

                // Create a service factory to get the organization service.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    // TODO: Add your plugin logic here for the Delete operation.
                    // Example: Perform some calculations, validations, or updates to related records.                    
                }
                catch (Exception ex)
                {
                    //throw new InvalidPluginExecutionException(ex.ToString());
                }
            }
        }
    }
}
